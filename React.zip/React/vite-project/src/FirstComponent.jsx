function FirstComponent()
{
    return  <h2>This is my first React component</h2>
}
export default FirstComponent;